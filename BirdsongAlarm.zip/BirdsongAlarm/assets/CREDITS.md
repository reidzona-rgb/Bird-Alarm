# Credits

Recordings from xeno-canto.org and photos from iNaturalist.org, used under
the Creative Commons licence named on each line. Personal, non-commercial use.

## Song Sparrow
- Audio: not fetched yet
- Photo: not fetched yet

## Tufted Titmouse
- Audio: not fetched yet
- Photo: not fetched yet

## American Robin
- Audio: not fetched yet
- Photo: not fetched yet

## Northern Cardinal
- Audio: not fetched yet
- Photo: not fetched yet

## Black-capped Chickadee
- Audio: not fetched yet
- Photo: not fetched yet

## Carolina Wren
- Audio: not fetched yet
- Photo: not fetched yet

## Wood Thrush
- Audio: not fetched yet
- Photo: not fetched yet

## Eastern Bluebird
- Audio: not fetched yet
- Photo: not fetched yet

## American Goldfinch
- Audio: not fetched yet
- Photo: not fetched yet

## Baltimore Oriole
- Audio: not fetched yet
- Photo: not fetched yet

## Eastern Meadowlark
- Audio: not fetched yet
- Photo: not fetched yet

## Red-winged Blackbird
- Audio: not fetched yet
- Photo: not fetched yet

## Mourning Dove
- Audio: not fetched yet
- Photo: not fetched yet

## White-throated Sparrow
- Audio: not fetched yet
- Photo: not fetched yet

## Indigo Bunting
- Audio: not fetched yet
- Photo: not fetched yet

## Rose-breasted Grosbeak
- Audio: not fetched yet
- Photo: not fetched yet

## Eastern Towhee
- Audio: not fetched yet
- Photo: not fetched yet

## Common Yellowthroat
- Audio: not fetched yet
- Photo: not fetched yet

## Hermit Thrush
- Audio: not fetched yet
- Photo: not fetched yet

## Eastern Wood-Pewee
- Audio: not fetched yet
- Photo: not fetched yet
